# DonutCase - DonutSMP Case Opening Mod

**Minecraft 26.2 | Fabric | Client-side only**

## Funkciók

- **J** gomb → HUD ki/be kapcsolása
- Idle állapotban a case-ek között automatikusan lapoz (név + ár megjelenik)
- Ha `/pay <játékos> <összeg>` parancsot írsz, és az összeg megegyezik egy case árával → automatikusan elindul a 5 itemes pörgetés
- A pörgetés után chatben kiírja az eredményt (nyertél / vesztettél + összegek)
- Az itemek árai **fixek**, nem a DonutSMP AH/market áraitól függenek

## Case-ek (alapértelmezett)

| Case név         | Ár      |
|------------------|---------|
| Bronze Case      | 500k    |
| Gold Case        | 1M      |
| Diamond Case     | 5M      |
| Netherite Case   | 10M     |
| Emerald Case     | 25M     |
| Amethyst Case    | 50M     |
| Legendary Case   | 100M    |

## Telepítés

1. Telepítsd a **Fabric Loader**-t 26.2-re
2. Tedd be a `donutcase-1.0.0.jar`-t a `mods` mappába
3. Fabric API is kell (0.155.2+26.2 vagy újabb)

## Fordítás (ha forrásból akarod)

```bash
./gradlew build
```

A kész jar a `build/libs/` mappában lesz.

## Megjegyzések

- Csak a **saját** `/pay` parancsaidat figyeli (ClientSendMessageEvents.COMMAND).
- A scale (méret) jelenleg 1.0-ra van állítva. A J+görgő funkciót a következő verzióban finomítom (MouseScrollCallback).
- Az item poolokat és az árakat a `DonutCaseClient.java` `initCases()` metódusában tudod módosítani.

## Fejlesztendő

- J + egérgörgő pontos méretezés
- Szebb pörgetés animáció (slot machine stílus)
- Több case / custom case config fájlból
- Hanghatások

Készítette: Grok (xAI)
