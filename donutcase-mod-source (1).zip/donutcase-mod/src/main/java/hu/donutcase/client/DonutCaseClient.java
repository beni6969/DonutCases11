package hu.donutcase.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DonutCaseClient implements ClientModInitializer {

    public static final String MOD_ID = "donutcase";

    private static KeyMapping toggleKey;
    private static boolean hudEnabled = true;
    private static float hudScale = 1.0f;

    private static final List<CaseData> CASES = new ArrayList<>();
    private static int currentCaseIndex = 0;
    private static long lastCaseSwitch = 0;
    private static final long CASE_SWITCH_INTERVAL = 4000; // 4 másodperc

    // Aktív pörgetés
    private static boolean isSpinning = false;
    private static CaseData activeCase = null;
    private static List<CaseItem> spunItems = new ArrayList<>();
    private static int spinTick = 0;
    private static final int SPIN_DURATION = 60; // tick

    private static final Random RANDOM = new Random();

    @Override
    public void onInitializeClient() {
        // Case-ek létrehozása (fix árakkal)
        initCases();

        // Keybind: J
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.donutcase.toggle",
                GLFW.GLFW_KEY_J,
                "category.donutcase"
        ));

        // Tick esemény (keybind + case lapozás + spin)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // J gomb lenyomás
            while (toggleKey.consumeClick()) {
                hudEnabled = !hudEnabled;
                client.player.displayClientMessage(
                        Component.literal(hudEnabled ? "§aDonutCase HUD bekapcsolva" : "§cDonutCase HUD kikapcsolva"),
                        true
                );
            }

            // Case lapozás idle-ben
            if (!isSpinning && System.currentTimeMillis() - lastCaseSwitch > CASE_SWITCH_INTERVAL) {
                currentCaseIndex = (currentCaseIndex + 1) % CASES.size();
                lastCaseSwitch = System.currentTimeMillis();
            }

            // Spin animáció
            if (isSpinning) {
                spinTick++;
                if (spinTick >= SPIN_DURATION) {
                    isSpinning = false;
                    finishSpin(client);
                }
            }
        });

        // /pay detektálás (amikor a játékos elküldi a parancsot)
        ClientSendMessageEvents.COMMAND.register((command) -> {
            if (command.startsWith("pay ")) {
                handlePayCommand(command);
            }
            return true; // engedd elküldeni
        });

        // HUD render
        HudRenderCallback.EVENT.register((graphics, tickDelta) -> {
            if (!hudEnabled) return;
            renderHud(graphics, Minecraft.getInstance());
        });

        // J + görgő = méret változtatás
        // Egyszerű megoldás: tick-ben figyeljük a J lenyomott állapotát + scroll delta-t (később pontosítható)
        // Most a scale-t manuálisan is lehet állítani a kódban, vagy később MouseScrollCallback-kel
    }

    private void initCases() {
        // 500k Case
        CASES.add(new CaseData("Bronze Case", 500_000L, List.of(
                new CaseItem("Iron Block", 80_000),
                new CaseItem("Gold Block", 150_000),
                new CaseItem("Diamond", 120_000),
                new CaseItem("Emerald", 90_000),
                new CaseItem("Netherite Scrap", 200_000),
                new CaseItem("Ancient Debris", 350_000),
                new CaseItem("Netherite Ingot", 600_000)
        )));

        // 1M Case
        CASES.add(new CaseData("Gold Case", 1_000_000L, List.of(
                new CaseItem("Diamond Block", 400_000),
                new CaseItem("Netherite Ingot", 550_000),
                new CaseItem("Elytra", 1_200_000),
                new CaseItem("Netherite Block", 2_000_000),
                new CaseItem("Beacon", 800_000),
                new CaseItem("Shulker Box", 300_000),
                new CaseItem("Totem of Undying", 450_000)
        )));

        // 5M Case
        CASES.add(new CaseData("Diamond Case", 5_000_000L, List.of(
                new CaseItem("Netherite Block", 2_000_000),
                new CaseItem("Elytra", 1_200_000),
                new CaseItem("Spawner", 3_500_000),
                new CaseItem("Beacon", 800_000),
                new CaseItem("Dragon Egg", 8_000_000),
                new CaseItem("Nether Star", 1_500_000),
                new CaseItem("Enchanted Golden Apple", 600_000)
        )));

        // 10M Case
        CASES.add(new CaseData("Netherite Case", 10_000_000L, List.of(
                new CaseItem("Spawner", 3_500_000),
                new CaseItem("Dragon Egg", 8_000_000),
                new CaseItem("Netherite Block x4", 8_000_000),
                new CaseItem("Elytra + Firework", 2_500_000),
                new CaseItem("Full Netherite Set", 6_000_000),
                new CaseItem("Beacon x3", 2_400_000),
                new CaseItem("Jackpot Bundle", 25_000_000)
        )));

        // 25M Case
        CASES.add(new CaseData("Emerald Case", 25_000_000L, List.of(
                new CaseItem("Spawner x2", 7_000_000),
                new CaseItem("Dragon Egg", 8_000_000),
                new CaseItem("Netherite Block x8", 16_000_000),
                new CaseItem("Full Netherite + Elytra", 9_000_000),
                new CaseItem("Beacon x5", 4_000_000),
                new CaseItem("Shulker Box x16", 5_000_000),
                new CaseItem("Mega Jackpot", 60_000_000)
        )));

        // 50M Case
        CASES.add(new CaseData("Amethyst Case", 50_000_000L, List.of(
                new CaseItem("Spawner x3", 10_500_000),
                new CaseItem("Dragon Egg x2", 16_000_000),
                new CaseItem("Netherite Block x16", 32_000_000),
                new CaseItem("Full Gear Bundle", 20_000_000),
                new CaseItem("Beacon x10", 8_000_000),
                new CaseItem("Elytra + Mace", 15_000_000),
                new CaseItem("Ultra Jackpot", 120_000_000)
        )));

        // 100M Case
        CASES.add(new CaseData("Legendary Case", 100_000_000L, List.of(
                new CaseItem("Spawner x5", 17_500_000),
                new CaseItem("Dragon Egg x3", 24_000_000),
                new CaseItem("Netherite Block x32", 64_000_000),
                new CaseItem("God Bundle", 45_000_000),
                new CaseItem("Beacon x20", 16_000_000),
                new CaseItem("Full End Game Set", 50_000_000),
                new CaseItem("Godly Jackpot", 250_000_000)
        )));
    }

    private void handlePayCommand(String command) {
        // pay <player> <amount>
        String[] parts = command.split("\\s+");
        if (parts.length < 3) return;

        try {
            String amountStr = parts[2].replace(",", "").replace(".", "").replace("k", "000").replace("m", "000000").replace("b", "000000000");
            long amount = Long.parseLong(amountStr);

            for (CaseData c : CASES) {
                if (c.price == amount) {
                    startSpin(c);
                    Minecraft.getInstance().player.displayClientMessage(
                            Component.literal("§e[DonutCase] §f" + c.name + " nyitás indítva (" + formatMoney(amount) + ")"),
                            false
                    );
                    return;
                }
            }
        } catch (NumberFormatException ignored) {
        }
    }

    private void startSpin(CaseData caseData) {
        if (isSpinning) return;
        activeCase = caseData;
        spunItems.clear();
        isSpinning = true;
        spinTick = 0;

        // 5 random item a case pooljából
        for (int i = 0; i < 5; i++) {
            spunItems.add(caseData.items.get(RANDOM.nextInt(caseData.items.size())));
        }
    }

    private void finishSpin(Minecraft client) {
        if (activeCase == null || spunItems.isEmpty()) return;

        long totalValue = 0;
        for (CaseItem item : spunItems) {
            totalValue += item.value;
        }

        long profit = totalValue - activeCase.price;
        String resultColor = profit >= 0 ? "§a" : "§c";
        String resultText = profit >= 0 ? "NYERTÉL" : "VESZTETTÉL";

        client.player.displayClientMessage(Component.literal("§6========== DonutCase Eredmény =========="), false);
        client.player.displayClientMessage(Component.literal("§eCase: §f" + activeCase.name + " (" + formatMoney(activeCase.price) + ")"), false);
        for (int i = 0; i < spunItems.size(); i++) {
            CaseItem item = spunItems.get(i);
            client.player.displayClientMessage(Component.literal("§7#" + (i + 1) + " §f" + item.name + " §7→ §e" + formatMoney(item.value)), false);
        }
        client.player.displayClientMessage(Component.literal("§eÖsszérték: §f" + formatMoney(totalValue)), false);
        client.player.displayClientMessage(Component.literal(resultColor + resultText + " §f" + formatMoney(Math.abs(profit))), false);
        client.player.displayClientMessage(Component.literal("§6====================================="), false);

        activeCase = null;
        spunItems.clear();
    }

    private void renderHud(GuiGraphics graphics, Minecraft client) {
        if (client.player == null || client.options.hideGui) return;

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();

        // Méretezés (J + scroll később kezeljük inputtal, egyelőre fix scale)
        float scale = hudScale;

        graphics.pose().pushPose();
        graphics.pose().scale(scale, scale, 1.0f);

        int x = (int) (10 / scale);
        int y = (int) (10 / scale);

        if (isSpinning && activeCase != null) {
            // Spinning HUD
            graphics.fill(x, y, x + 220, y + 90, 0xAA000000);
            graphics.drawString(client.font, "§e" + activeCase.name + " NYITÁS...", x + 8, y + 8, 0xFFFFFF, true);

            int progress = (int) ((spinTick / (float) SPIN_DURATION) * 200);
            graphics.fill(x + 8, y + 25, x + 8 + progress, y + 30, 0xFF55FF55);

            // Mutasd a pörgetett itemeket (animáltan)
            for (int i = 0; i < Math.min(5, spunItems.size()); i++) {
                CaseItem item = spunItems.get(i);
                int alpha = (spinTick > i * 10) ? 0xFFFFFF : 0x888888;
                graphics.drawString(client.font, "§7" + (i + 1) + ". §f" + item.name, x + 8, y + 40 + i * 10, alpha, true);
            }
        } else {
            // Idle case carousel
            CaseData c = CASES.get(currentCaseIndex);
            graphics.fill(x, y, x + 180, y + 50, 0xAA000000);
            graphics.drawString(client.font, "§6" + c.name, x + 8, y + 8, 0xFFFFFF, true);
            graphics.drawString(client.font, "§eÁr: §f" + formatMoney(c.price), x + 8, y + 22, 0xFFFFFF, true);
            graphics.drawString(client.font, "§7J = ki/be | J+görgő = méret", x + 8, y + 36, 0xAAAAAA, true);
        }

        graphics.pose().popPose();
    }

    private String formatMoney(long amount) {
        if (amount >= 1_000_000_000) return String.format("%.1fB", amount / 1_000_000_000.0);
        if (amount >= 1_000_000) return String.format("%.1fM", amount / 1_000_000.0);
        if (amount >= 1_000) return String.format("%.0fK", amount / 1_000.0);
        return String.valueOf(amount);
    }

    // ===== Adat osztályok =====

    public static class CaseData {
        public final String name;
        public final long price;
        public final List<CaseItem> items;

        public CaseData(String name, long price, List<CaseItem> items) {
            this.name = name;
            this.price = price;
            this.items = items;
        }
    }

    public static class CaseItem {
        public final String name;
        public final long value;

        public CaseItem(String name, long value) {
            this.name = name;
            this.value = value;
        }
    }
}